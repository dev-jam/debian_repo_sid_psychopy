import importlib.metadata
__version__ = importlib.metadata.version("psychopy-eyelink-coregraphics")
_last_updated = '09/19/2024'

from .EyeLinkCoreGraphicsPsychoPy import EyeLinkCoreGraphicsPsychoPy
